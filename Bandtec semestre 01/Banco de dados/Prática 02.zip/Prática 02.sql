	-- Criando o banco de dados
    CREATE DATABASE revista;
    
    -- Usando o banco de dados
    USE revista;
    
    -- Criando a tabela
    CREATE TABLE revistas (
    -- Nomeando os campos e os tipos
    id_revista INT PRIMARY KEY,
    nome VARCHAR (40),
    categoria VARCHAR (30)
    );
    
    
    -- Inserindo valores na tabela
    
INSERT INTO revistas VALUES
(1, 'VOGUE', ''),
(2, 'Bravo',''),
(3,'Quatro Rodas',''),
(4,'Superinteressante','');    

-- Exibir os itens da tabela
SELECT * FROM revistas;

-- Adicionando a categoria
UPDATE revistas set categoria = 'Moda' where id_revista = 1;
UPDATE revistas set categoria = 'Artes' where id_revista = 2;
UPDATE revistas set categoria = 'Automóveis' where id_revista = 3;
UPDATE revistas set categoria = 'Curiosidades' where id_revista = 4;

-- Inserindo mais valores à tabela
INSERT INTO revistas values 
(5, 'Você s/a', 'Finanças'),
(6,'DIOR', 'Moda'),
(7, 'Rascunhos','Artes' ),
(8, 'PET','Animais');

-- Exibindo todos os dados da tabela antiga + atualizada
SELECT * FROM revistas;

-- Descrição da estrutura da tabela
DESC revistas;

-- Alterando a tabela
ALTER TABLE revistas MODIFY COLUMN categoria VARCHAR (40);

-- Adicionando uma coluna nova
ALTER TABLE revistas ADD COLUMN periodicidade VARCHAR (15);

-- Excluindo a coluna periodicidade
ALTER TABLE revistas DROP COLUMN periodicidade;
    
    